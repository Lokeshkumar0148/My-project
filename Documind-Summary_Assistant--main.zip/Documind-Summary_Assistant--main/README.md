# 📄 DocuMind Summary Assistant



**Documind Summary Assistant** is a smart full-stack web app that helps you **upload any document (PDF/Image)** and get:  
✅ **AI-powered Summaries**  
✅ **Improvement Suggestions**  

It saves time by giving you the **key points** and **refined recommendations** instantly! 🚀  

🌐 **Live Demo:** [Documind Summary Assistant](https://documind-summary-assistant.vercel.app/)  
📂 **Repository:** [GitHub Repo](https://github.com/mayank-kumar03/Documind-Summary_Assistant-)

---

## ✨ Features

### 📤 1. Document Upload
- Upload **PDFs** and **images (scanned docs)**.  
- Drag & Drop support.

### 📝 2. Text Extraction
- Extracts text from **PDFs**.  
- Uses **OCR (Tesseract.js)** for images.

### 🤖 3. AI Summary
- Generates **short, medium, long summaries**.  
- Focus on **important insights**.

### 💡 4. Suggestions
- Improves **clarity, readability, structure**.  
- Tailored recommendations.

### 🗂️ 5. Output Sections
- Results are shown in **two clear cards**:  
  - 📑 **Summary**  
  - 💡 **Suggestions**

---

## 🛠️ Tech Stack

### **Frontend**
- ⚛️ React.js (Vite)  
- 🎨 Tailwind CSS  
- 🌐 Axios  

### **Backend**
- 🟢 Node.js  
- 🚀 Express.js  

### **AI & OCR**
- 🤖 Google Gemini API  
- 🔍 Tesseract.js  

### **Deployment**
- ▲ Vercel (Frontend)  
- 🔗 Render (Backend)  


---

## 📂 Project Structure
```bash
Documind-Summary-Assistant/
│── backend/
│   ├── src/
│   │   ├── controllers/   # Business logic
│   │   |
│   │   ├── routes/        # API Routes
│   │   ├── services/      # AI & OCR
│   │   └── app.js         # App Entry
│   ├── uploads/           # Uploaded files (ignored in Git)
│   └── package.json
│
├──assistant_frontend/              # React Frontend
│   ├── src/
│   ├── public/
│   └── package.json
│
├── .env  for store in local private key
├── .gitignore
├── README.md
```

---

## ⚡ Quick Start

### 1️⃣ Clone Repo
```bash
git clone https://github.com/mayank-kumar03/Documind-Summary_Assistant-
cd Documind-Summary-Assistant
```

### 2️⃣ Backend Setup
```bash
cd backend
npm install
```

Create **.env** inside `backend/`:
```env
PORT=5000
GOOGLE_API_KEY=your_google_gemini_api_key
```

Run backend:
```bash
npm run start
```

### 3️⃣ Frontend Setup
```bash
cd ../assistant_frontend
npm install
npm run dev
```

---

## ☁️ Deployment
- **Frontend** → Vercel  
- **Backend** → Render  

---

## 🚀 Future Enhancements
- 🌍 Multi-language support  
- 📝 Bullet-point smart summaries    

---

<p align="center">
  Made with ❤️ by Mayank Kumar
</p>
