// backend/src/services/geminiService.js
import { GoogleGenerativeAI } from "@google/generative-ai";
import dotenv from "dotenv";
dotenv.config();

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY); 

function buildPrompt(text, length = "medium") {
  const lengthMap = {
    short: `Summarize the document in **30-60 words** using **bullet points**.  
- Highlight the **core points** and **main ideas** in **bold**.  
- Capture only the **essential information**.  
After the summary, provide **2-3 improvement suggestions** for the document, also in bullet points, with key actions in **bold**.`,

    medium: `Summarize the document in **100-150 words** using **bullet points**.  
- Include the **main points**, **key details**, and **essential insights** in **bold**.  
After the summary, provide **3-5 improvement suggestions**, also in bullet points, with recommended changes emphasized in **bold**.`,

    long: `Summarize the document in **300-400 words** using **bullet points**.  
- Preserve the **structure**, **major arguments**, and **essential details** in **bold**.  
After the summary, provide **5-7 improvement suggestions**, also in bullet points, highlighting key recommendations in **bold**.`
  };

  return `${lengthMap[length]}\n\nDocument:\n${text}`;
}
export async function summarizeWithGemini(text, length) {
  try {
    const model = genAI.getGenerativeModel({ model: "gemini-2.5-flash" });
    const prompt = `Summarize this text in a ${length} format:\n\n${text}`;
    const result = await model.generateContent(prompt);
    return result.response.text();
  } catch (err) {
    if (err.status === 429) {
      return "⚠️ Daily quota exceeded. Please try again tomorrow.";
    }
    throw err;
  }
}
