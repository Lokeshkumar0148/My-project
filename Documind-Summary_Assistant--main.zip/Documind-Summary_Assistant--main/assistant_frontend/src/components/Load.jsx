import React, { useState } from "react";
import axios from "axios";
import { motion } from "framer-motion";
import ReactMarkdown from "react-markdown";
import { Upload, FileText, Lightbulb } from "lucide-react";

export default function Load() {
  const [file, setFile] = useState(null);
  const [length, setLength] = useState("short");
  const [loading, setLoading] = useState(false);
  const [summary, setSummary] = useState(null);
  const [suggestions, setSuggestions] = useState(null);
  const [error, setError] = useState(null);
  const [darkMode, setDarkMode] = useState(false);

  const onSubmit = async (e) => {
    e.preventDefault();
    if (!file) {
      alert("Please select a file first!");
      return;
    }

    const formData = new FormData();
    formData.append("file", file);
    formData.append("length", length);

    try {
      setLoading(true);
      setError(null);

      const res = await axios.post(
        `${import.meta.env.VITE_API_URL}/api/upload`,
        formData,
        { headers: { "Content-Type": "multipart/form-data" } }
      );

      const fullText = res.data.summary || "";
      const parts = fullText.split(/Improvement Suggestions:/i);
      setSummary(parts[0]?.trim() || "");
      setSuggestions(parts[1]?.trim() || "");
    } catch (err) {
      console.error(err);
      setError("Something went wrong. Try again!");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      className={`min-h-screen flex items-center justify-center transition-colors duration-500 ${
        darkMode
          ? "bg-gradient-to-br from-gray-900 via-black to-gray-800 text-white"
          : "bg-gradient-to-br from-blue-100 via-purple-100 to-pink-100 text-gray-900"
      }`}
    >
      {/* Dark/Light Mode Floating Button */}
      <button
        onClick={() => setDarkMode(!darkMode)}
        className="fixed bottom-6 right-6 p-4 rounded-full shadow-xl
                   bg-gradient-to-r from-purple-500 to-pink-500 text-white font-bold
                   hover:scale-105 transition-all"
      >
        {darkMode ? "☀️" : "🌙"}
      </button>

      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="grid md:grid-cols-2 gap-8 w-full max-w-6xl p-6"
      >
        {/* Upload + Controls Card */}
        <div
          className="p-8 rounded-3xl shadow-xl backdrop-blur-xl 
                     bg-white/50 dark:bg-gray-800/40 border border-white/20"
        >
          <h1 className="text-3xl font-bold mb-6 flex items-center gap-2">
            <Upload className="w-7 h-7 text-purple-600" /> Upload Document
          </h1>

          <form onSubmit={onSubmit} className="space-y-6">
            {/* File Upload */}
            <label
              className="flex flex-col items-center justify-center w-full h-32 px-4 py-6 
                            border-2 border-dashed rounded-2xl cursor-pointer 
                            bg-white/40 dark:bg-gray-700/30 hover:bg-white/60 
                            transition-all duration-300"
            >
              <input
                type="file"
                accept=".pdf,.png,.jpg,.jpeg"
                onChange={(e) => setFile(e.target.files[0])}
                className="hidden"
              />
              {file ? (
                <p className="text-sm font-medium text-blue-600 dark:text-blue-400">
                  {file.name}
                </p>
              ) : (
                <p className="text-gray-600 dark:text-gray-300">
                  Drag & drop or click to upload PDF/Image
                </p>
              )}
            </label>

            {/* Length Selector */}
            <motion.select
              whileHover={{ scale: 1.01 }}
              value={length}
              onChange={(e) => setLength(e.target.value)}
              className="w-full rounded-xl p-3 
                       bg-white/40 dark:bg-gray-800/40 
                       border border-transparent backdrop-blur-xl 
                       text-gray-900 dark:text-white shadow-inner
                       focus:ring-2 focus:ring-purple-400 transition-all"
            >
              <option value="short">Short</option>
              <option value="medium">Medium</option>
              <option value="long">Long</option>
            </motion.select>

            {/* Button */}
            <motion.button
              whileTap={{ scale: 0.97 }}
              whileHover={{ scale: 1.02 }}
              type="submit"
              disabled={loading}
              className="w-full py-3 rounded-xl font-semibold tracking-wide
                         bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-lg
                         hover:from-blue-700 hover:to-purple-700 disabled:from-gray-400 disabled:to-gray-500
                         transition-all duration-300"
            >
              {loading ? " Processing..." : " Upload & Summarize"}
            </motion.button>
          </form>

          {error && (
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-red-500 mt-4 text-center font-medium"
            >
              {error}
            </motion.p>
          )}
        </div>

        {/* Results Card */}
        <div className="flex flex-col gap-6">
          {/* Summary Section */}
          {summary && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="p-6 rounded-2xl border border-white/20 dark:border-gray-600 
                         bg-white/60 dark:bg-gray-700/50 backdrop-blur-md shadow-lg"
            >
              <h3 className="text-xl font-semibold mb-3 flex items-center gap-2">
                <FileText className="w-6 h-6 text-blue-600" /> Summary
              </h3>
              <div className="prose dark:prose-invert max-w-none">
                <ReactMarkdown>{summary}</ReactMarkdown>
              </div>
            </motion.div>
          )}

          {/* Suggestions Section */}
          {suggestions && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="p-6 rounded-2xl border border-white/20 dark:border-gray-600 
                         bg-white/60 dark:bg-gray-700/50 backdrop-blur-md shadow-lg"
            >
              <h3 className="text-xl font-semibold mb-3 flex items-center gap-2">
                <Lightbulb className="w-6 h-6 text-yellow-500" /> Improvement Suggestions
              </h3>
              <div className="prose dark:prose-invert max-w-none">
                <ReactMarkdown>{suggestions}</ReactMarkdown>
              </div>
            </motion.div>
          )}
        </div>
      </motion.div>
    </div>
  );
}
